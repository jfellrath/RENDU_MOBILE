package myapplication.exemple.com.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Sport extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sport);

        TextView txt_def = (TextView)findViewById(R.id.textView_definition);
        Intent i = getIntent();
        txt_def.setText(i.getStringExtra("definition"));
    }

    public void onClickSport(View v){

        Intent i = new Intent(v.getContext(),SportMenu.class);
        startActivity(i);
    }

    public void onClickAcceuil(View v){

        Intent i = new Intent(v.getContext(),Menu.class);
        startActivity(i);
    }
}
