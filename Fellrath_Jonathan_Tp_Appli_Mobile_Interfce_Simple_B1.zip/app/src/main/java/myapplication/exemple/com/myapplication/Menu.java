package myapplication.exemple.com.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }

    public void onClick(View v){
        //EditText txt = (EditText)findViewById(R.id.nomEdit);

        // Intent qui permet d'aller au menu de renseignement des informations de l'utilisateur
        Intent i = new Intent(v.getContext(),Information_Utilisateur.class);
        //i.putExtra("Nom",txt.getText().toString());*/

        startActivity(i);
    }


}
