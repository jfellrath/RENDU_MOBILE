package myapplication.exemple.com.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;

public class Information_Utilisateur extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information__utilisateur);
    }

    public void onClick(View v){
        RadioButton radio_M = (RadioButton)findViewById(R.id.radio_Civilite_m);
        RadioButton radio_Mme = (RadioButton)findViewById(R.id.radio_Civilite_mme);
        EditText txt_nom = (EditText)findViewById(R.id.editText_nom);
        EditText txt_prenom = (EditText)findViewById(R.id.edit_prenom);
        EditText txt_dateNaissance = (EditText)findViewById(R.id.edit_date_naissance);
        EditText txt_email = (EditText)findViewById(R.id.edit_email);
        EditText txt_adressePostal = (EditText)findViewById(R.id.edit_adressePostal);
        EditText txt_commentaire = (EditText)findViewById(R.id.edit_commentaire);

        // Intent qui permet d'aller au menu de renseignement des informations de l'utilisateur
        Intent i = new Intent(v.getContext(),Jeu.class);
        if(radio_M.isChecked()){
            i.putExtra("civilite_m","M.");
        }else if(radio_Mme.isChecked()){
            i.putExtra("civilite_m","Mme.");
        }
        i.putExtra("nom",txt_nom.getText().toString());
        i.putExtra("prenom",txt_prenom.getText().toString());
        i.putExtra("date_naissance",txt_dateNaissance.getText().toString());
        i.putExtra("email",txt_email.getText().toString());
        i.putExtra("adressePostal",txt_adressePostal.getText().toString());
        i.putExtra("Commentaire",txt_commentaire.getText().toString());

        startActivity(i);
    }
}
