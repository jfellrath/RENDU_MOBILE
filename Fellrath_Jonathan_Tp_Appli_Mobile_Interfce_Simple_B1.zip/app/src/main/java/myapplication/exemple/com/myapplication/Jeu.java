package myapplication.exemple.com.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Jeu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jeu);

        Intent i = getIntent();
        TextView txt_civilite = (TextView)findViewById(R.id.textView_civilite);
        TextView txt_nom = (TextView)findViewById(R.id.textView_nom);
        TextView txt_prenom = (TextView)findViewById(R.id.textView_prenom);
        TextView txt_dateNaissance = (TextView)findViewById(R.id.textView_date_naissance);
        TextView txt_email = (TextView)findViewById(R.id.textView_email);
        TextView txt_adressePostal = (TextView)findViewById(R.id.textView_adresse_postal);
        TextView txt_commentaire = (TextView)findViewById(R.id.textView_commentaire);

        if(i!=null) {
            txt_civilite.setText(i.getStringExtra("civilite_m"));
            txt_nom.setText(i.getStringExtra("nom"));
            txt_prenom.setText(i.getStringExtra("prenom"));
            txt_dateNaissance.setText(i.getStringExtra("date_naissance"));
            txt_email.setText(i.getStringExtra("email"));
            txt_adressePostal.setText(i.getStringExtra("adressePostal"));
            txt_commentaire.setText(i.getStringExtra("Commentaire"));
        }
    }

    public void onClickSport(View v){

        Intent i = new Intent(v.getContext(),SportMenu.class);
        startActivity(i);
    }

    public void onClickAcceuil(View v){

        Intent i = new Intent(v.getContext(),Menu.class);
        startActivity(i);
    }
}
