package myapplication.exemple.com.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class SportMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sport_menu);
    }

    public void onClickAcceuil(View v){

        Intent i = new Intent(v.getContext(),Menu.class);
        startActivity(i);
    }

    public void onClickSport1(View v){

        Intent i = new Intent(v.getContext(),Sport.class);
        i.putExtra("definition","La formule1 est un sport de course dans des voitures très rapide (300km/h environs)");
        startActivity(i);
    }

    public void onClickSport2(View v){

        String def = "La boxe est sport de combat à deux. Chaque adversaire doit se taper dessus en respectant des règles. Le premier Ko a perdu";

        Intent i = new Intent(v.getContext(),Sport.class);
        i.putExtra("definition",def);
        startActivity(i);
    }

    public void onClickSport3(View v){

        String def = "Le Hockey sur glaçe est un peu comme le foot sauf qu'ont tape dans un palet à l'aide d'un cross (baton de Hockey";

        Intent i = new Intent(v.getContext(),Sport.class);
        i.putExtra("definition",def);
        startActivity(i);
    }
}
